#!/bin/bash
catkin build kvh_geo_fog_3d_driver -DCMAKE_BUILD_TYPE=Debug